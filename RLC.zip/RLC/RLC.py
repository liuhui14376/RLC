import math
import numpy as np
import pandas as pd
import spectral
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
import os
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder  # 导入标签编码器
import numpy as np  # 确保导入numpy（若未导入）
import seaborn as sns
import matplotlib
import warnings
import time
import joblib
import torch
import torch.nn as nn
import torch.nn.functional as F  # 关键：导入PyTorch的functional模块
from sklearn.metrics import cohen_kappa_score, precision_score, recall_score, f1_score



class TimeMix(nn.Module):
    def __init__(self, params):
        super().__init__()
        self.n_attn = params.get('n_attn')  # 注意力维度
        self.n_head = params.get('n_head')  # 注意力头数
        self.ctx_len = params.get('ctx_len')  # 上下文长度
        self.n_embd = params.get('n_embd')  # 输入维度设置为 128
        # 检查 n_attn 是否能被 n_head 整除
        assert self.n_attn % self.n_head == 0, "n_attn must be divisible by n_head"
        self.head_size = self.n_attn // self.n_head  # 每个注意力头的维度

        # 初始化 time_w 曲线
        with torch.no_grad():
            ww = torch.ones(self.n_head, self.ctx_len)
            curve = torch.tensor([-(self.ctx_len - 1 - i) for i in range(self.ctx_len)])  # 距离
            for h in range(self.n_head):
                if h < self.n_head - 1:
                    decay_speed = math.pow(self.ctx_len, -(h + 1) / (self.n_head - 1))
                else:
                    decay_speed = 0.0
                ww[h] = torch.exp(curve * decay_speed)
            self.time_w = nn.Parameter(ww)

        # 初始化其他参数
        self.time_alpha = nn.Parameter(torch.ones(self.n_head, 1, self.ctx_len))
        self.time_beta = nn.Parameter(torch.ones(self.n_head, self.ctx_len, 1))
        self.time_gamma = nn.Parameter(torch.ones(self.ctx_len, 1))

        # 时间位移操作
        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))

        # 定义线性层
        self.key = nn.Linear(128, 64)  # 输入维度为 128，输出维度为 64
        self.value = nn.Linear(128, 64)  # 输入维度为 128，输出维度为 64
        self.receptance = nn.Linear(128, 64)  # 输入维度为 128，输出维度为 64

        # 输出层
        self.output = nn.Linear(64, 64)  # 输入维度为 64，输出维度为 64

        # 初始化 scale_init
        self.key.scale_init = 0
        self.receptance.scale_init = 0
        self.output.scale_init = 0

    def forward(self, x):
        B, T, C = x.size()  # 输入形状: (B, T, C)
        TT = self.ctx_len

        # 打印输入数据的形状
        # print(f"TimeMix Input shape: {x.shape}")

        # 如果输入维度不匹配，调整维度
        if x.shape[-1] != 128:
            # print(f"Adjusting input dimension from {x.shape[-1]} to 128")
            x = nn.Linear(x.shape[-1], 128)
            # print(f"Adjusted input shape: {x.shape}")

        # 构造时间权重矩阵
        w = F.pad(self.time_w, (0, TT))
        # print(f"Padded time_w shape: {w.shape}")
        w = torch.tile(w, [TT])
        # print(f"Tiled w shape: {w.shape}")
        w = w[:, :-TT].reshape(-1, TT, 2 * TT - 1)
        # print(f"Reshaped w shape: {w.shape}")
        w = w[:, :, TT - 1:]  # w 现在是一个循环矩阵
        # print(f"Final w shape: {w.shape}")
        w = w[:, :T, :T] * self.time_alpha[:, :, :T] * self.time_beta[:, :T, :]
        # print(f"Scaled w shape: {w.shape}")
        band_weights = torch.ones_like(w)
        band_weights[:, :, 12:20] = 5.0
        w = w * band_weights

        # 时间位移操作
        x = torch.cat([self.time_shift(x[:, :, :C // 2]), x[:, :, C // 2:]], dim=-1)
        # print(f"Time-shifted x shape: {x.shape}")

        # 计算 key、value 和 receptance
        k = self.key(x)
        v = self.value(x)
        r = self.receptance(x)

        # 动态计算 head_size
        assert self.n_head > 0, "n_head must be greater than 0"
        assert k.size(-1) % self.n_head == 0, "k.size(-1) must be divisible by n_head"
        head_size = k.size(-1) // self.n_head
        # print(f"head_size: {head_size}")

        # 计算加权 value
        kv = (k * v).view(B, T, self.n_head, head_size)
        # print(f"kv shape: {kv.shape}")

        # 检查 w 和 kv 的值
        if torch.isnan(w).any() or torch.isinf(w).any():
            raise ValueError("w contains NaN or inf values")
        if torch.isnan(kv).any() or torch.isinf(kv).any():
            raise ValueError("kv contains NaN or inf values")

        wkv = (torch.einsum('htu,buhc->bthc', w, kv)).contiguous().view(B, T, -1)
        # print(f"wkv shape: {wkv.shape}")

        # 计算最终输出
        eps = 1e-8  # 添加一个小常数，避免除零错误
        r = torch.clamp(r, min=-50, max=50)  # 限制 r 的范围
        rwkv = torch.sigmoid(r) * wkv / (torch.cumsum(k, dim=1) + eps)
        rwkv = self.output(rwkv)

        # 打印输出形状
        # print(f"TimeMix Output shape: {rwkv.shape}")

        return rwkv * self.time_gamma[:T, :]

class TinyAttn(nn.Module):
    def __init__(self, params):
        super().__init__()
        self.params = params
        net_params = params['net']
        self.d_attn = net_params.get('rwkv_tiny_attn', 64)
        self.n_head = net_params.get('rwkv_tiny_head', 4)
        self.head_size = self.d_attn // self.n_head
        # 1. 修复qkv输入维度（确保与TimeMix输出一致）
        self.qkv = nn.Linear(net_params.get('n_embd'), self.d_attn * 3)
        # 2. 添加LayerNorm稳定训练（关键！注意力模块必须加归一化）
        self.norm = nn.LayerNorm(self.d_attn)
        self.out = nn.Linear(self.d_attn, net_params.get('n_embd'))
        self.dropout = nn.Dropout(0.1)

    def forward(self, x, mask):
        B, T, C = x.size()
        # 1. LayerNorm归一化（防止输入分布漂移）
        x = self.norm(x)
        # 2. qkv线性变换+拆分
        qkv = self.qkv(x).chunk(3, dim=-1)  # (B, T, d_attn) * 3
        q, k, v = [t.view(B, T, self.n_head, self.head_size).transpose(1, 2) for t in qkv]

        # 3. 注意力计算（添加缩放+掩码+dropout）
        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_size)  # 缩放
        attn = attn.masked_fill(mask.unsqueeze(1).unsqueeze(2) == 0, -1e9)  # 掩码
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)

        # 4. 输出（残差连接！必须添加，否则特征退化）
        out = (attn @ v).transpose(1, 2).contiguous().view(B, T, C)
        return x + self.out(out)  # 残差连接（关键！缓解梯度消失）


class LSTMTimeMixTinyAttnExtractor(nn.Module):
    def __init__(self, input_dim, lstm_hidden_dim=128, timemix_params=None, tinyattn_params=None):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=lstm_hidden_dim,
            num_layers=2,
            batch_first=True,
            dropout=0.5,
            bidirectional=False
        )

        self.tinyattn = TinyAttn(tinyattn_params)
        self.timemix = TimeMix(timemix_params)


        self.final_proj = nn.Linear(64, 64)

    def forward(self, x, mask=None):

        lstm_out, (h_n, _) = self.lstm(x)
        lstm_feat = h_n[-1].unsqueeze(1)


        timemix_feat = self.timemix(lstm_feat)

        if mask is None:
            mask = torch.ones(timemix_feat.shape[0], timemix_feat.shape[1], device=x.device)
        tinyattn_feat = self.tinyattn(timemix_feat, mask)


        return self.final_proj(tinyattn_feat).squeeze(1)

def train_rf_lstm_timemix_tinyattn(X_train, y_train, X_test, y_test, class_names, save_dir, ctx_len=1):
    model_save_dir = os.path.join(save_dir, "rf_lstm_timemix_tinyattn")
    os.makedirs(model_save_dir, exist_ok=True)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    joblib.dump(scaler, os.path.join(model_save_dir, "scaler.pkl"))

    rf_selector = RandomForestClassifier(
        n_estimators=500, random_state=42, n_jobs=-1
    )
    rf_selector.fit(X_train_scaled, y_train)


    importances = rf_selector.feature_importances_
    indices = np.argsort(importances)[::-1]

    n_selected_features = max(10, int(X_train.shape[1] * 0.5))
    selected_indices = indices[:n_selected_features]

    X_train_selected = X_train_scaled[:, selected_indices]
    X_test_selected = X_test_scaled[:, selected_indices]


    X_train_seq = X_train_selected.reshape(-1, ctx_len, n_selected_features)
    X_test_seq = X_test_selected.reshape(-1, ctx_len, n_selected_features)

    timemix_params = {
        'n_attn': 64,
        'n_head': 4,
        'ctx_len': ctx_len,
        'n_embd': 128
    }

    tinyattn_params = {
        'net': {
            'rwkv_tiny_attn': 64,
            'rwkv_tiny_head': 4,
            'n_embd': 64
        }
    }

    class RF_LSTM_TimeMix_TinyAttn(nn.Module):
        def __init__(self, input_dim, num_classes, timemix_params, tinyattn_params):
            super().__init__()

            self.feature_extractor = LSTMTimeMixTinyAttnExtractor(
                input_dim=input_dim,
                lstm_hidden_dim=128,
                timemix_params=timemix_params,
                tinyattn_params=tinyattn_params
            )

            self.classifier = nn.Sequential(
                nn.Linear(64, 32),
                nn.ReLU(),
                nn.Dropout(0.4),
                nn.Linear(32, num_classes)
            )

        def forward(self, x):
            features = self.feature_extractor(x)

            logits = self.classifier(features)

            return logits, features

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = RF_LSTM_TimeMix_TinyAttn(
        input_dim=n_selected_features,
        num_classes=len(class_names),
        timemix_params=timemix_params,
        tinyattn_params=tinyattn_params
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5, factor=0.5)
    criterion = nn.CrossEntropyLoss()

    X_train_tensor = torch.tensor(X_train_seq, dtype=torch.float32).to(device)
    y_train_tensor = torch.tensor(y_train, dtype=torch.long).to(device)
    X_test_tensor = torch.tensor(X_test_seq, dtype=torch.float32).to(device)

    train_losses = []
    train_accuracies = []
    best_accuracy = 0.0

    model.train()
    for epoch in range(100):
        optimizer.zero_grad()

        logits, _ = model(X_train_tensor)
        loss = criterion(logits, y_train_tensor)
        loss.backward()

        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

        optimizer.step()

        with torch.no_grad():
            preds = logits.argmax(dim=1)
            acc = (preds == y_train_tensor).float().mean().item()
            acc_percent = acc * 100

        train_losses.append(loss.item())
        train_accuracies.append(acc_percent)

    return model, model_save_dir


def invert_hyperspectral_data(hyperspectral_data, model_checkpoint, selected_indices, scaler_path,
                              rededge_method='FD', band_config=None, model_type="rf_lstm_timemix_tinyattn",
                              batch_size=1000, device="cpu"):
    print(f"开始使用 {model_type} 模型进行高光谱数据反演...")

    # 如果没有提供band_config，使用默认配置
    if band_config is None:
        band_config = {
            'B37': 36, 'B38': 37, 'B39': 38, 'B40': 39, 'B41': 40
        }
        print("使用默认波段配置")

    # 加载scaler
    if os.path.exists(scaler_path):
        scaler = joblib.load(scaler_path)
        print("成功加载scaler")
    else:
        print("警告: 未找到scaler文件，使用原始数据")
        scaler = None

    # 获取原始图像形状
    original_shape = hyperspectral_data.shape[:2]
    num_bands = hyperspectral_data.shape[2]

    # 重塑为二维数组 (像素数, 波段数)
    print(f"原始数据形状: {hyperspectral_data.shape}")
    pixels = hyperspectral_data.reshape(-1, num_bands)
    print(f"重塑后数据形状: {pixels.shape}")

    # 为每个像素添加红边特征
    print(f"添加红边特征 (方法: {rededge_method})...")
    pixels_with_rededge = []

    # 红边算法配置
    rededge_config = {
        'FD': (lambda p: p[band_config['B40']], band_config['B40']),
        'IG': (lambda p: p[band_config['B37']], band_config['B37']),
        'REP': (lambda p: p[band_config['B38']], band_config['B38']),
        'LE': (lambda p: 0.4 * p[band_config['B40']] + 0.6 * p[band_config['B41']], band_config['B41'] - 1),
        'LAGR': (lambda p: 0.2 * p[band_config['B40']] + 0.8 * p[band_config['B41']], band_config['B41']),
        'WT': (lambda p: p[band_config['B39']], band_config['B39'])
    }

    rededge_func, slope_center_band = rededge_config[rededge_method]
    red_edge_window = 5
    red_edge_area_start = 30
    red_edge_area_end = 50

    for i in range(len(pixels)):
        pixel = pixels[i]

        # 计算三个红边特征
        feature1 = rededge_func(pixel)

        # 斜率特征
        slope_start = max(0, slope_center_band - red_edge_window)
        slope_end = min(len(pixel) - 1, slope_center_band + red_edge_window)
        if slope_end > slope_start:
            feature2 = (pixel[slope_end] - pixel[slope_start]) / (slope_end - slope_start)
        else:
            feature2 = 0

        # 面积特征
        area_start = max(0, red_edge_area_start)
        area_end = min(len(pixel), red_edge_area_end)
        feature3 = np.sum(pixel[area_start:area_end])

        # 合并原始波段和红边特征
        pixel_with_features = np.concatenate([pixel, [feature1, feature2, feature3]])
        pixels_with_rededge.append(pixel_with_features)

    pixels_with_rededge = np.array(pixels_with_rededge)
    print(f"添加红边特征后数据形状: {pixels_with_rededge.shape}")

    # 数据预处理
    if scaler is not None:
        pixels_scaled = scaler.transform(pixels_with_rededge)
        print("数据标准化完成")
    else:
        pixels_scaled = pixels_with_rededge.astype(np.float32)
        print("使用原始数据（未标准化）")

    # 特征选择 - 注意：selected_indices应该包含红边特征的索引
    # 如果selected_indices是基于原始波段的，需要调整
    pixels_selected = pixels_scaled[:, selected_indices]
    print(f"特征选择完成，选择 {len(selected_indices)} 个特征")

    # 转换为序列格式
    pixels_seq = pixels_selected.reshape(-1, 1, len(selected_indices))
    print(f"序列数据形状: {pixels_seq.shape}")

    # 从检查点重新创建模型
    if isinstance(model_checkpoint, dict):
        print("从检查点字典重新创建模型...")

        # 获取模型参数
        model_params = model_checkpoint
        input_dim = model_params.get('input_dim', len(selected_indices))
        num_classes = model_params.get('num_classes', 5)
        timemix_params = model_params.get('timemix_params', {})
        tinyattn_params = model_params.get('tinyattn_params', {})

        # 重新创建完整的模型实例
        class RF_LSTM_TimeMix_TinyAttn(nn.Module):
            def __init__(self, input_dim, num_classes, timemix_params, tinyattn_params):
                super().__init__()
                self.feature_extractor = LSTMTimeMixTinyAttnExtractor(
                    input_dim=input_dim,
                    lstm_hidden_dim=128,
                    timemix_params=timemix_params,
                    tinyattn_params=tinyattn_params
                )
                self.classifier = nn.Sequential(
                    nn.Linear(64, 32),
                    nn.ReLU(),
                    nn.Dropout(0.4),
                    nn.Linear(32, num_classes)
                )

            def forward(self, x):
                features = self.feature_extractor(x)
                logits = self.classifier(features)
                return logits, features

        model = RF_LSTM_TimeMix_TinyAttn(
            input_dim=input_dim,
            num_classes=num_classes,
            timemix_params=timemix_params,
            tinyattn_params=tinyattn_params
        ).to(device)

        # 加载模型权重
        model.load_state_dict(model_checkpoint['model_state_dict'])
        model.eval()
        print("模型加载成功")
    else:
        # 已经是模型对象
        model = model_checkpoint
        model.eval()
        print("直接使用模型对象")

    # 批量预测
    print("开始批量预测...")
    predictions = []

    # 转换为tensor
    pixels_tensor = torch.tensor(pixels_seq, dtype=torch.float32).to(device)

    with torch.no_grad():
        for i in range(0, len(pixels_tensor), batch_size):
            start_idx = i
            end_idx = min(i + batch_size, len(pixels_tensor))
            batch = pixels_tensor[start_idx:end_idx]

            logits, _ = model(batch)
            batch_preds = logits.argmax(dim=1).cpu().numpy()
            predictions.extend(batch_preds)

            if (i // batch_size) % 10 == 0 or end_idx == len(pixels_tensor):
                progress = (end_idx / len(pixels_tensor)) * 100
                print(f"已处理 {end_idx}/{len(pixels_tensor)} 个像素 ({progress:.1f}%)")

    # 转换为numpy数组并重塑为原始图像形状
    predictions = np.array(predictions)
    prediction_image = predictions.reshape(original_shape)

    print(f"反演完成，预测结果形状: {prediction_image.shape}")

    return prediction_image


